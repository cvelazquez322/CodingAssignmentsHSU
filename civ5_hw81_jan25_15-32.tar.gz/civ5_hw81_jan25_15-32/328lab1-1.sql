/*	
*	328lab1-1.sql
*	Christopher Velazquez
*	1/25/19
*
*/



spool 328lab1-out.txt

prompt Christopher Velazquez

select *
from empl;



spool off
