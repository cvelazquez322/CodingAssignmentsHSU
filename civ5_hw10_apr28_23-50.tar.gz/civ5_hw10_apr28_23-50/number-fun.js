"use strict"

function stuffDone()
{
	var num1 = parseFloat(document.getElementById("num1").value);
	
	var num2 = parseFloat(document.getElementById("num2").value);
	
	alert(num1 + num2);
	
}